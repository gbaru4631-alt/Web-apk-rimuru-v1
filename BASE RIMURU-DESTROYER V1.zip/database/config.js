module.exports = {
  tokens: "8541241440:AAHSuccj3gvOAmGZ45Oi7XWtj4IVrb088Pc",  // Ubah Jadi Token Bot Mu !!!
  owner: "6265792556", // Ubah Jadi Id Mu !!!
  port: "2083", // Ubah Jadi Port Panel Mu !!!
  ipvps: "165.22.110.251" // Ubah Jadi Ip Vps Mu !!!
};